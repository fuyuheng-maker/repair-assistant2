# 简单测试：直接测试下载API
import requests

# 先登录获取token
print("登录...")
login_data = {"username": "傅昱衡", "password": "123456"}
resp = requests.post('http://localhost:8000/api/login', data=login_data)
print(f"登录状态: {resp.status_code}")

if resp.status_code == 200:
    token = resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    
    # 测试各种路径
    print("\n测试不同路径:")
    
    # 测试健康检查
    resp = requests.get('http://localhost:8000/health')
    print(f"/health: {resp.status_code}")
    
    # 测试文件列表
    resp = requests.get('http://localhost:8000/api/files', headers=headers)
    print(f"/api/files: {resp.status_code}")
    
    # 获取文件ID
    if resp.status_code == 200:
        data = resp.json()
        if data.get("files") and len(data["files"]) > 0:
            file_id = data["files"][0]["file_id"]
            
            # 测试下载
            print(f"\n文件ID: {file_id}")
            resp = requests.get(f'http://localhost:8000/api/files/{file_id}/download', headers=headers)
            print(f"/api/files/{file_id}/download: {resp.status_code}")
            
            # 测试删除
            resp = requests.delete(f'http://localhost:8000/api/files/{file_id}', headers=headers)
            print(f"/api/files/{file_id} DELETE: {resp.status_code}")
            
            # 测试其他路径
            resp = requests.get('http://localhost:8000/api/test', headers=headers)
            print(f"/api/test: {resp.status_code}")

print("\n测试完成")
