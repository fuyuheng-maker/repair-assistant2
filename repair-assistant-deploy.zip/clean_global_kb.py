import chromadb

client = chromadb.PersistentClient(path="./chroma_db")

try:
    global_collection = client.get_collection("knowledge_global")
    all_data = global_collection.get()
    
    if all_data and all_data.get("ids") and len(all_data["ids"]) > 0:
        print(f"全局知识库中共有 {len(all_data['ids'])} 条记录")
        print("正在删除所有记录...")
        global_collection.delete(ids=all_data["ids"])
        print(f"已删除 {len(all_data['ids'])} 条记录")
    else:
        print("全局知识库为空")
except Exception as e:
    print(f"Error: {e}")