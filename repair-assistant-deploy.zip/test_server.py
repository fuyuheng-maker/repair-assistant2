# 简单测试脚本
import subprocess
import time
import requests

# 启动服务器
print("启动服务器...")
server = subprocess.Popen(['python', 'main.py'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

# 等待启动
time.sleep(3)

# 检查是否启动成功
try:
    # 测试健康检查
    print("\n[1] 测试健康检查...")
    resp = requests.get('http://localhost:8000/health', timeout=5)
    print(f"状态码: {resp.status_code}")
    print(f"响应: {resp.text}")

    # 测试登录
    print("\n[2] 测试登录...")
    login_data = {
        "username": "傅昱衡",
        "password": "123456"
    }
    resp = requests.post('http://localhost:8000/api/login', data=login_data, timeout=5)
    print(f"状态码: {resp.status_code}")
    
    if resp.status_code == 200:
        token = resp.json()["access_token"]
        print(f"✓ 登录成功，Token: {token[:20]}...")
        
        # 测试文件列表
        print("\n[3] 测试文件列表...")
        headers = {"Authorization": f"Bearer {token}"}
        resp = requests.get('http://localhost:8000/api/files', headers=headers, timeout=5)
        print(f"状态码: {resp.status_code}")
        
        if resp.status_code == 200:
            data = resp.json()
            files = data.get("files", [])
            print(f"✓ 获取成功，共 {len(files)} 个文件")
            
            if len(files) > 0:
                file = files[0]
                print(f"\n文件信息:")
                print(f"  - ID: {file['file_id']}")
                print(f"  - 名称: {file['filename']}")
                print(f"  - 所有者: {file['username']}")
                
                # 测试下载
                print("\n[4] 测试下载API...")
                resp = requests.get(f'http://localhost:8000/api/files/{file["file_id"]}/download', headers=headers, timeout=30)
                print(f"状态码: {resp.status_code}")
                
                if resp.status_code == 200:
                    print("✓ 下载成功")
                    print(f"  - Content-Type: {resp.headers.get('content-type')}")
                    print(f"  - 文件大小: {len(resp.content) / 1024 / 1024:.2f} MB")
                else:
                    print(f"✗ 下载失败: {resp.text}")
        else:
            print(f"✗ 获取文件列表失败: {resp.text}")
    else:
        print(f"✗ 登录失败: {resp.text}")

except Exception as e:
    print(f"❌ 请求失败: {e}")

finally:
    # 停止服务器
    print("\n停止服务器...")
    server.terminate()
    server.wait()
    print("服务器已停止")
