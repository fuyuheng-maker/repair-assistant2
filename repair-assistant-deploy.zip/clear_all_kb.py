import chromadb

client = chromadb.PersistentClient(path="./chroma_db")

collections = client.list_collections()

print("=== 清理所有知识库数据 ===")

for col in collections:
    print(f"\n集合: {col.name}")
    all_data = col.get()
    if all_data and all_data.get("ids") and len(all_data["ids"]) > 0:
        print(f"  记录数: {len(all_data['ids'])}")
        
        has_motorcycle = False
        for doc in all_data["documents"]:
            if "摩托车" in str(doc):
                has_motorcycle = True
                break
        
        if has_motorcycle:
            print("  ⚠️ 包含摩托车相关内容")
            print("  正在删除...")
            col.delete(ids=all_data["ids"])
            print("  ✓ 删除完成")
        else:
            print("  不包含摩托车内容，保留")
    else:
        print("  该集合为空")

print("\n=== 清理完成 ===")