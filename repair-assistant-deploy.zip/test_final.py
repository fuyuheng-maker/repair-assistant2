import requests

print("=" * 50)
print("API功能测试")
print("=" * 50)

# 1. 登录
print("\n[1] 登录测试...")
resp = requests.post('http://localhost:8000/api/login',
                     data={"username": "傅昱衡", "password": "123456"},
                     timeout=5)
if resp.status_code != 200:
    print(f"✗ 登录失败: {resp.status_code}")
    exit(1)

token = resp.json()["access_token"]
headers = {"Authorization": f"Bearer {token}"}
print(f"✓ 登录成功")

# 2. 文件列表
print("\n[2] 文件列表测试...")
resp = requests.get('http://localhost:8000/api/files', headers=headers, timeout=5)
print(f"  状态: {resp.status_code}")
files = resp.json().get("files", [])
print(f"  文件数量: {len(files)}")

# 如果有文件，测试下载
if files:
    file_id = files[0]["file_id"]
    filename = files[0]["filename"]

    print(f"\n[3] 下载测试 ({filename})...")
    resp = requests.get(f'http://localhost:8000/api/files/{file_id}/download',
                        headers=headers, timeout=30)
    print(f"  状态: {resp.status_code}")
    if resp.status_code == 200:
        print(f"  ✓ 下载成功! ({len(resp.content) / 1024:.1f} KB)")
    else:
        print(f"  ✗ 下载失败")

    print(f"\n[4] 删除测试...")
    resp = requests.delete(f'http://localhost:8000/api/files/{file_id}',
                          headers=headers, timeout=10)
    print(f"  状态: {resp.status_code}")
    if resp.status_code == 200:
        print(f"  ✓ 删除成功!")
    else:
        print(f"  ✗ 删除失败: {resp.text}")
else:
    print("\n[跳过] 没有文件可测试")

print("\n" + "=" * 50)
print("测试完成!")
print("=" * 50)
