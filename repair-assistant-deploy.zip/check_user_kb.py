import chromadb

client = chromadb.PersistentClient(path="./chroma_db")

username = "傅昱衡"
collection_name = f"knowledge_{username}"

try:
    user_collection = client.get_collection(collection_name)
    all_data = user_collection.get()
    
    if all_data and all_data.get("ids") and len(all_data["ids"]) > 0:
        print(f"用户 {username} 的知识库中共有 {len(all_data['ids'])} 条记录")
        print("\n--- 记录详情 ---")
        for i, (doc_id, doc, meta) in enumerate(zip(all_data["ids"], all_data["documents"], all_data["metadatas"])):
            print(f"\n记录 {i+1}:")
            print(f"ID: {doc_id}")
            print(f"来源: {meta.get('source', 'unknown')}")
            print(f"文件ID: {meta.get('file_id', 'unknown')}")
            print(f"内容预览: {doc[:100]}...")
    else:
        print(f"用户 {username} 的知识库为空")
except Exception as e:
    print(f"Error: {e}")