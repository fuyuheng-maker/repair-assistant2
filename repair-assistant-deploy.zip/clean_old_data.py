import chromadb

client = chromadb.PersistentClient(path="./chroma_db")

collections = client.list_collections()

print("=== 清理旧数据 ===")

for col in collections:
    if col.name == "user_test":
        print(f"找到测试集合: {col.name}")
        all_data = col.get()
        if all_data and all_data.get("ids") and len(all_data["ids"]) > 0:
            print(f"  记录数: {len(all_data['ids'])}")
            print("  正在删除...")
            col.delete(ids=all_data["ids"])
            print("  ✓ 删除完成")
        else:
            print("  该集合为空")

print("\n=== 清理完成 ===")