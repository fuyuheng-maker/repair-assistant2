# 测试脚本 - 用于测试文件下载和删除API
import requests
import json

# 配置
BASE_URL = "http://localhost:8000"

def test_apis():
    print("=" * 60)
    print("API 测试脚本")
    print("=" * 60)

    # 1. 尝试登录
    print("\n[1] 登录测试...")
    login_data = {
        "username": "傅昱衡",
        "password": "123456"  # 如果密码不是这个，请修改
    }

    try:
        resp = requests.post(f"{BASE_URL}/api/login", data=login_data)
        print(f"状态码: {resp.status_code}")

        if resp.status_code == 200:
            token = resp.json()["access_token"]
            print(f"✓ 登录成功，Token: {token[:20]}...")
            headers = {"Authorization": f"Bearer {token}"}
        else:
            print(f"✗ 登录失败: {resp.text}")
            return
    except Exception as e:
        print(f"✗ 登录请求失败: {e}")
        return

    # 2. 获取文件列表
    print("\n[2] 获取文件列表...")
    try:
        resp = requests.get(f"{BASE_URL}/api/files", headers=headers)
        print(f"状态码: {resp.status_code}")

        if resp.status_code == 200:
            data = resp.json()
            files = data.get("files", [])
            print(f"✓ 获取成功，共 {len(files)} 个文件")

            if len(files) > 0:
                file = files[0]
                print(f"\n文件信息:")
                print(f"  - ID: {file['file_id']}")
                print(f"  - 名称: {file['filename']}")
                print(f"  - 所有者: {file['username']}")
                file_id = file['file_id']
            else:
                print("✗ 没有文件")
                return
        else:
            print(f"✗ 获取失败: {resp.text}")
            return
    except Exception as e:
        print(f"✗ 获取文件列表失败: {e}")
        return

    # 3. 测试下载API
    print(f"\n[3] 测试下载API (文件ID: {file_id})...")
    try:
        resp = requests.get(f"{BASE_URL}/api/files/{file_id}/download", headers=headers, timeout=30)
        print(f"状态码: {resp.status_code}")

        if resp.status_code == 200:
            content_type = resp.headers.get('content-type', '')
            content_length = resp.headers.get('content-length', 'unknown')
            print(f"✓ 下载成功")
            print(f"  - Content-Type: {content_type}")
            print(f"  - Content-Length: {content_length}")

            # 保存文件测试
            test_file = f"test_download_{file_id}.pdf"
            with open(test_file, 'wb') as f:
                f.write(resp.content)
            import os
            size = os.path.getsize(test_file)
            print(f"  - 下载文件大小: {size / 1024 / 1024:.2f} MB")
            print(f"  - 已保存到: {test_file}")
            os.remove(test_file)
            print(f"  - 已删除测试文件")
        else:
            print(f"✗ 下载失败")
            try:
                error = resp.json()
                print(f"  - 错误: {error.get('detail', 'Unknown')}")
            except:
                print(f"  - 响应: {resp.text[:200]}")
    except Exception as e:
        print(f"✗ 下载请求失败: {e}")

    # 4. 测试删除API (警告用户)
    print(f"\n[4] 测试删除API")
    print("⚠️  注意: 接下来会实际删除文件!")
    print("跳过删除测试以避免意外删除数据")
    print("如需测试，请在命令行手动执行删除操作")

    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)

if __name__ == "__main__":
    test_apis()
