import requests
import sys

try:
    print("测试服务...")
    resp = requests.get('http://localhost:8000/', timeout=5)
    print(f"✓ 服务正常!")
    print(f"  状态码: {resp.status_code}")
    print(f"  内容长度: {len(resp.text)} bytes")
    sys.exit(0)
except Exception as e:
    print(f"✗ 服务异常: {e}")
    sys.exit(1)
