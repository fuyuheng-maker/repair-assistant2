import chromadb

client = chromadb.PersistentClient(path="./chroma_db")

collections = client.list_collections()

print(f"共有 {len(collections)} 个集合:")
for col in collections:
    print(f"\n=== 集合: {col.name} ===")
    all_data = col.get()
    if all_data and all_data.get("ids") and len(all_data["ids"]) > 0:
        print(f"记录数: {len(all_data['ids'])}")
        for i, (doc_id, doc, meta) in enumerate(zip(all_data["ids"], all_data["documents"], all_data["metadatas"])):
            print(f"\n记录 {i+1}:")
            print(f"ID: {doc_id}")
            print(f"来源: {meta.get('source', 'unknown')}")
            print(f"文件ID: {meta.get('file_id', 'unknown')}")
            print(f"内容预览: {doc[:150]}")
            if "摩托车" in doc:
                print(" ⚠️ 包含摩托车相关内容")
    else:
        print("该集合为空")