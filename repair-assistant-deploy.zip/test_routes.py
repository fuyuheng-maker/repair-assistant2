# 测试所有API端点
import requests

# 登录获取token
print("登录...")
resp = requests.post('http://localhost:8000/api/login', data={"username": "傅昱衡", "password": "123456"})
if resp.status_code != 200:
    print(f"登录失败: {resp.status_code}")
    exit()

token = resp.json()["access_token"]
headers = {"Authorization": f"Bearer {token}"}

# 获取文件列表
print("\n获取文件列表...")
resp = requests.get('http://localhost:8000/api/files', headers=headers)
print(f"状态: {resp.status_code}")
files = resp.json().get("files", [])
if not files:
    print("没有文件")
    exit()

file_id = files[0]["file_id"]
print(f"文件ID: {file_id}")

# 测试各种路径
print("\n测试路径:")

# 1. 文件列表
resp = requests.get('http://localhost:8000/api/files', headers=headers)
print(f"GET /api/files: {resp.status_code}")

# 2. 下载 - 使用不同的方式
resp = requests.get(f'http://localhost:8000/api/files/{file_id}/download', headers=headers)
print(f"GET /api/files/{file_id}/download: {resp.status_code} - {resp.text[:100]}")

# 3. 删除
resp = requests.delete(f'http://localhost:8000/api/files/{file_id}', headers=headers)
print(f"DELETE /api/files/{file_id}: {resp.status_code} - {resp.text[:200]}")

# 4. 测试中间路径
resp = requests.get('http://localhost:8000/api/files/test', headers=headers)
print(f"GET /api/files/test: {resp.status_code}")

# 5. 查看OpenAPI文档
resp = requests.get('http://localhost:8000/openapi.json')
print(f"\nOpenAPI文档获取: {resp.status_code}")
if resp.status_code == 200:
    paths = resp.json().get("paths", {})
    print(f"已注册的API路径 ({len(paths)} 个):")
    for path in sorted(paths.keys()):
        methods = list(paths[path].keys())
        print(f"  {path}: {methods}")
