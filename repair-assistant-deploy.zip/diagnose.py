"""诊断脚本 - 用于排查认证和文件访问问题"""
import json
import os

def diagnose():
    print("=" * 60)
    print("诊断报告")
    print("=" * 60)

    # 1. 检查用户数据
    print("\n[1] 用户数据:")
    if os.path.exists("users.json"):
        with open("users.json", "r", encoding="utf-8") as f:
            users = json.load(f)
        print(f"  - 共有 {len(users)} 个用户")
        for u in users:
            print(f"    - 用户名: {u['username']}, 角色: {u['role']}")
    else:
        print("  - users.json 不存在")

    # 2. 检查文件注册表
    print("\n[2] 文件注册表:")
    if os.path.exists("file_registry.json"):
        with open("file_registry.json", "r", encoding="utf-8") as f:
            files = json.load(f)
        print(f"  - 共有 {len(files)} 个文件记录")
        for f in files:
            print(f"    - 文件ID: {f['file_id']}")
            print(f"      文件名: {f['filename']}")
            print(f"      所有者: {f['username']}")
            print(f"      知识片段: {f.get('chunk_count', 0)} 个")

            # 检查实际文件是否存在
            pdf_path = os.path.join("uploads", f"{f['file_id']}.pdf")
            if os.path.exists(pdf_path):
                size = os.path.getsize(pdf_path)
                print(f"      文件状态: ✓ 存在 ({size} bytes)")
            else:
                print(f"      文件状态: ✗ 不存在")
    else:
        print("  - file_registry.json 不存在")

    # 3. 检查 uploads 目录
    print("\n[3] uploads 目录:")
    if os.path.exists("uploads"):
        pdf_files = [f for f in os.listdir("uploads") if f.endswith('.pdf')]
        print(f"  - 共有 {len(pdf_files)} 个 PDF 文件")
        if len(pdf_files) > 0:
            print("  - 文件列表:")
            for f in pdf_files[:5]:
                size = os.path.getsize(os.path.join("uploads", f))
                print(f"    - {f} ({size} bytes)")
    else:
        print("  - uploads 目录不存在")

    # 4. 检查 ChromaDB
    print("\n[4] ChromaDB 知识库:")
    if os.path.exists("chroma_db"):
        collections = [d for d in os.listdir("chroma_db") if os.path.isdir(os.path.join("chroma_db", d))]
        print(f"  - 共有 {len(collections)} 个 collection")
    else:
        print("  - chroma_db 目录不存在")

    print("\n" + "=" * 60)
    print("诊断完成")
    print("=" * 60)

if __name__ == "__main__":
    diagnose()
