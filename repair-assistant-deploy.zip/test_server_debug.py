# 带日志的测试脚本
import subprocess
import time
import requests
import threading
import sys

# 打印服务器输出的线程
def print_server_output(process):
    while True:
        line = process.stdout.readline()
        if line == '' and process.poll() is not None:
            break
        if line:
            print(f"[SERVER] {line.strip()}")
            sys.stdout.flush()

# 启动服务器
print("启动服务器...")
server = subprocess.Popen(['python', 'main.py'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)

# 启动日志线程
log_thread = threading.Thread(target=print_server_output, args=(server,))
log_thread.daemon = True
log_thread.start()

# 等待启动
time.sleep(3)

# 测试
try:
    print("\n[1] 测试健康检查...")
    resp = requests.get('http://localhost:8000/health', timeout=5)
    print(f"状态码: {resp.status_code}")

    print("\n[2] 测试登录...")
    login_data = {"username": "傅昱衡", "password": "123456"}
    resp = requests.post('http://localhost:8000/api/login', data=login_data, timeout=5)
    print(f"状态码: {resp.status_code}")
    
    if resp.status_code == 200:
        token = resp.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        
        print("\n[3] 测试文件列表...")
        resp = requests.get('http://localhost:8000/api/files', headers=headers, timeout=5)
        print(f"状态码: {resp.status_code}")
        
        if resp.status_code == 200:
            data = resp.json()
            if data.get("files") and len(data["files"]) > 0:
                file = data["files"][0]
                print(f"\n[4] 测试下载API...")
                print(f"文件ID: {file['file_id']}")
                resp = requests.get(f'http://localhost:8000/api/files/{file["file_id"]}/download', headers=headers, timeout=30)
                print(f"状态码: {resp.status_code}")
                print(f"响应: {resp.text[:500]}")

finally:
    print("\n停止服务器...")
    server.terminate()
    server.wait()
